import os
import uuid

from flask import Flask, jsonify, render_template, request, url_for
from werkzeug.security import generate_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)

UPLOAD_FOLDER = os.path.join(app.static_folder, "uploads")
ALLOWED_PHOTO_EXTENSIONS = {"jpg", "jpeg", "png"}
MAX_PHOTO_SIZE = 2 * 1024 * 1024  # 2 MB

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# In-memory "database" of registered students.
students = []


def allowed_photo(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_PHOTO_EXTENSIONS


@app.route("/", methods=["GET"])
def register_page():
    """Shows the registration form."""
    return render_template("register.html", form={})


@app.route("/register", methods=["POST"])
def register():
    """Handles the registration form submitted via fetch()/JS."""
    form = request.form

    full_name = form.get("full_name", "").strip()
    email = form.get("email", "").strip()
    mobile = form.get("mobile", "").strip()
    dob = form.get("dob", "").strip()
    gender = form.get("gender", "").strip()
    course = form.get("course", "").strip()
    qualification = form.get("qualification", "").strip()
    training_mode = form.get("training_mode", "").strip()
    skills = form.getlist("skills")
    experience = form.get("experience", "").strip()
    address = form.get("address", "").strip()
    website = form.get("website", "").strip()
    password = form.get("password", "")
    confirm_password = form.get("confirm_password", "")
    agree = form.get("agree")

    # --- Required-field validation (mirrors the required fields in the form) ---
    required = {
        "full_name": full_name,
        "email": email,
        "mobile": mobile,
        "dob": dob,
        "gender": gender,
        "course": course,
        "qualification": qualification,
        "training_mode": training_mode,
        "address": address,
        "password": password,
        "confirm_password": confirm_password,
    }
    missing = [name for name, value in required.items() if not value]
    if missing:
        return jsonify({"error": "Please fill in all required fields."}), 400

    if not skills:
        return jsonify({"error": "Please select at least one skill."}), 400

    if not agree:
        return jsonify({"error": "You must agree to register."}), 400

    if password != confirm_password:
        return jsonify({"error": "Passwords do not match."}), 400

    try:
        experience_value = int(experience) if experience else 0
        if experience_value < 0:
            raise ValueError
    except ValueError:
        return jsonify({"error": "Years of experience must be a non-negative number."}), 400

    # --- Optional photo upload ---
    photo_filename = None
    photo = request.files.get("photo")
    if photo and photo.filename:
        if not allowed_photo(photo.filename):
            return jsonify({"error": "Photo must be a JPEG or PNG file."}), 400

        photo.seek(0, os.SEEK_END)
        size = photo.tell()
        photo.seek(0)
        if size > MAX_PHOTO_SIZE:
            return jsonify({"error": "Photo size must be under 2 MB."}), 400

        ext = photo.filename.rsplit(".", 1)[1].lower()
        photo_filename = f"{uuid.uuid4().hex}.{ext}"
        photo.save(os.path.join(app.config["UPLOAD_FOLDER"], secure_filename(photo_filename)))

    students.append(
        {
            "full_name": full_name,
            "email": email,
            "mobile": mobile,
            "dob": dob,
            "gender": gender,
            "course": course,
            "qualification": qualification,
            "training_mode": training_mode,
            "skills": skills,
            "experience": experience_value,
            "address": address,
            "website": website,
            "photo": photo_filename,
            "password_hash": generate_password_hash(password),
        }
    )

    return jsonify({"redirect_url": url_for("student_list")})


@app.route("/students", methods=["GET"])
def student_list():
    """Shows every registered student."""
    return render_template("students.html", students=students)


if __name__ == "__main__":
    app.run(debug=True)
