from flask import Flask, jsonify, redirect, render_template, request, url_for

app = Flask(__name__)
stories = []


@app.route("/", methods=["GET"])
def home():
    # The home page only displays the form and existing stories.
    return render_template("home.html", stories=stories, form={})


@app.route("/add-bracket", methods=["POST"])
def add_story_with_brackets():
    # This route reads submitted form values using bracket access.
    title = request.form["title"].strip()
    author = request.form["author"].strip()
    story = request.form["story"].strip()

    if not title or not author or not story:
        return jsonify({"error": "Please fill in all fields."}), 400

    stories.append({"title": title, "author": author, "story": story})
    return jsonify({"redirect_url": url_for("home")})


@app.route("/delete/<int:story_id>", methods=["POST"])
def delete_story(story_id):
    if story_id < 0 or story_id >= len(stories):
        return "Story not found", 404

    stories.pop(story_id)
    return redirect(url_for("home"))


@app.route("/edit/<int:story_id>", methods=["GET", "POST"])
def edit_story(story_id):
    if story_id < 0 or story_id >= len(stories):
        return "Story not found", 404

    story = stories[story_id]

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        author = request.form.get("author", "").strip()
        story_text = request.form.get("story", "").strip()

        if title and author and story_text:
            story.update({"title": title, "author": author, "story": story_text})
            return redirect(url_for("home"))

        return render_template(
            "edit_story.html",
            form=request.form,
            error="Please fill in all fields.",
        ), 400

    return render_template("edit_story.html", form=story)


if __name__ == "__main__":
    app.run(debug=True)
