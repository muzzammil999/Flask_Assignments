"""Application factory: builds the Flask app and wires config, database, CSRF and routes."""
import re
from decimal import Decimal

from flask import Flask, g, render_template

from .extensions import csrf, db


def inr(n):
    """Format a number as rupees with Indian digit grouping, e.g. 1234567.5 -> ₹12,34,567.50."""
    d = Decimal(n or 0).quantize(Decimal("0.01"))
    whole, frac = f"{abs(d):.2f}".split(".")
    if len(whole) > 3:
        whole = re.sub(r"(\d)(?=(\d\d)+$)", r"\1,", whole[:-3]) + "," + whole[-3:]
    return f"{'-' if d < 0 else ''}₹{whole}.{frac}"


def create_app(overrides=None):
    """Create the app. Needs SECRET_KEY; `overrides` lets tests swap the database.
    Registers blueprints, error pages, template filters and the CLI commands.
    """
    app = Flask(__name__)
    app.config.from_object("config.Config")
    app.config.update(overrides or {})
    if not app.config["SECRET_KEY"]:
        raise RuntimeError("Set the SECRET_KEY environment variable.")
    db.init_app(app)
    csrf.init_app(app)
    from . import auth, routes_admin, routes_claims, routes_main, seed
    app.before_request(auth.load_user)
    for module in (routes_main, routes_claims, routes_admin):
        app.register_blueprint(module.bp)
    seed.register(app)
    app.add_template_filter(lambda s: str(s or "").replace("_", " ").title(), "label")
    app.add_template_filter(inr, "inr")

    @app.context_processor
    def nav_counts():
        """Give every page the officer's unassigned-claim count for the sidebar badge."""
        user = getattr(g, "user", None)
        if user is None or user.role != "claims_officer":
            return {"queue_count": None}
        from .models import Claim
        from .services import visible_claims
        return {"queue_count": visible_claims(user).filter(Claim.status == "submitted", Claim.officer_user_id.is_(None)).count()}

    @app.errorhandler(403)
    @app.errorhandler(404)
    def error_page(e):
        """Show a friendly error page for forbidden and missing pages."""
        return render_template("error.html", e=e), e.code
    return app
